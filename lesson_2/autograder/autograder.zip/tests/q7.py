test = {   'name': 'q7',
    'points': 2,
    'suites': [   {   'cases': [{'code': '>>> isinstance(seconds, int)\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> seconds == 163620\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
