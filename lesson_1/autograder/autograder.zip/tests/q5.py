test = {   'name': 'q5',
    'points': 2,
    'suites': [{'cases': [{'code': '>>> last_twenty_sum == sum(super_long_list[-20:])\nTrue', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
