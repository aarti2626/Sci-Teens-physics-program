test = {   'name': 'q9',
    'points': 2,
    'suites': [   {   'cases': [{'code': '>>> isinstance(pounds, int)\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> pounds == 9798000\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
