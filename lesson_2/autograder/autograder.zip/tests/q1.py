test = {   'name': 'q1',
    'points': 3,
    'suites': [   {   'cases': [   {'code': '>>> y(72) == 297\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> y(10) == 49\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> y(0) == 9\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
