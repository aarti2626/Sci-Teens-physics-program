test = {   'name': 'q3',
    'points': 3,
    'suites': [   {   'cases': [   {'code': '>>> r(0) == 164\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> r(1) == 175\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> r(-5) == 1400779\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
