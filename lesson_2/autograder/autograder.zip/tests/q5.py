test = {   'name': 'q5',
    'points': 3,
    'suites': [   {   'cases': [   {'code': '>>> abs(kg_to_newtons(100) - 980) < 0.000001\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> abs(kg_to_newtons(3) - 29.4) < 0.000001\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> abs(kg_to_newtons(47) - 460.6) < 0.000001\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
