test = {   'name': 'q4',
    'points': 3,
    'suites': [   {   'cases': [   {'code': '>>> kinematic(1,1,1) == 3\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> kinematic(0,3,10) == 60\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> kinematic(10, 1, 5) == 110\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
