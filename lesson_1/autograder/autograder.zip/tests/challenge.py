test = {   'name': 'challenge',
    'points': 4,
    'suites': [   {   'cases': [   {   'code': '>>> values == [99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, '
                                               '126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149]\n'
                                               'True',
                                       'hidden': True,
                                       'locked': False},
                                   {'code': '>>> last_three == [21609, 21904, 22201]\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
