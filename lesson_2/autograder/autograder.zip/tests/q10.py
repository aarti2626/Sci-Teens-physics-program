test = {   'name': 'q10',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(decimeters, float)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> abs(decimeters - 0.678) < 0.000001\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
