test = {   'name': 'q2',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(phrase, str)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> phrase == 'I Love Data Science'\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
