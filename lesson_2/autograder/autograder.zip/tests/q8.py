test = {   'name': 'q8',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(meters, float)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> abs(meters - 10.5) < 0.000001\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
