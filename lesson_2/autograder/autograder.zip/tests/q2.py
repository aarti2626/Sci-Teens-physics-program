test = {   'name': 'q2',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> g(0) == 213\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> g(-100) == -999087\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> g(12) == 1857\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
