test = {   'name': 'q4',
    'points': 4,
    'suites': [   {   'cases': [   {'code': '>>> second == 1\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> first_five == [0, 1, 2, 3, 4]\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> last == 123456\nTrue', 'hidden': True, 'locked': False},
                                   {   'code': '>>> last_fourteen == [123443,\n'
                                               '...  123444,\n'
                                               '...  123445,\n'
                                               '...  123446,\n'
                                               '...  123447,\n'
                                               '...  123448,\n'
                                               '...  123449,\n'
                                               '...  123450,\n'
                                               '...  123451,\n'
                                               '...  123452,\n'
                                               '...  123453,\n'
                                               '...  123454,\n'
                                               '...  123455,\n'
                                               '...  123456]\n'
                                               'True',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
