test = {   'name': 'q3',
    'points': 2,
    'suites': [   {   'cases': [{'code': '>>> isinstance(hello, str)\nTrue', 'hidden': False, 'locked': False}, {'code': ">>> hello == 'HelloHelloHello'\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
