test = {   'name': 'q6',
    'points': 2,
    'suites': [   {   'cases': [{'code': '>>> isinstance(kph, float)\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> abs(kph - 48) < 0.000001\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
