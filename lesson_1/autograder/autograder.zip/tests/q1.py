test = {   'name': 'q1',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(solution_1, float)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> abs(solution_1 - -894660.96875) < 0.0000001\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
